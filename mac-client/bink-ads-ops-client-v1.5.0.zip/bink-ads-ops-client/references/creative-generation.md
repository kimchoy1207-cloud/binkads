# 소재 만들기 (이미지 · 영상 · 캐러셀)

> **OS 경계:** Claude는 생성 provider를 직접 dispatch하거나 자격증명·비용 원장을 소유하지 않는다. 소재 생성 요청·quote·승인·dispatch·결과·AI 표시·QA는 OS 제안과 감사 기록에 남긴다. Meta 부착은 운영 827 MAIN `BINK_` 또는 TEST 698809956850274 `TEST_BINK_`의 승인 envelope만 OS safe-write가 수행한다.

아래 provider/model 이름은 OS generation capability가 지원할 때의 기획 참고다. OS가 인증된 capability, settled quote, target-account policy hash, dispatch plan을 반환하지 않으면 생성하지 않는다.

## 공통 원칙

1. **실물에서 출발한다.** 제품·현장 사진을 레퍼런스로 넣는다. 글만으로 그리면 광고 속 물건이 실물과 달라진다.
   → **팔 물건이 없는 서비스·B2B는 아래 「실물이 없을 때」를 본다.**
2. **한 라운드에 변수 하나.** 포맷을 테스트하는 중에는 메시지를 고정한다.
3. **만들기 전에 OS quote를 확인하고 생성 승인을 받는다.** 힉스필드 크레딧도 사장님 돈이다. 영상은 이미지보다 훨씬 비싸다. quote는 account/run/cap/24시간 정책 hash에 결합되어야 하며 실제 정산액도 승인 상한을 넘을 수 없다.

   **라운드 도중에 크레딧이 떨어지면 운영이 멈춘다.** 다음 라운드에 필요한 양을 미리 계산해 두고, 잔액이 그보다 적어지면 **바닥나기 전에** 알린다. 광고는 돌아가는데 새 소재를 못 만드는 상태가 가장 나쁘다 — 소재 피로가 와도 대응할 수단이 없어진다.

   > 지금 크레딧으로 이미지 ○장 정도 더 만들 수 있습니다.
   > 다음 라운드에 △장이 필요해서, 그 전에 충전이 필요합니다.
4. **뽑은 뒤 원본과 비교한다.** 제품이 달라졌으면 실패 QA로 남기고, 새 생성은 새 dispatch/비용 승인 범위 안에서만 한다.
5. URL 자체가 아니라 OS가 보존·검증한 최종 artifact bytes hash와 승인된 placement를 Meta 제안에 결합한다 (`references/publishing.md`).

## 이미지

기본 모델 `marketing_studio_image` (상업/제품/광고용). 레퍼런스는 `medias: [{role: "image", value: <media_id 또는 이전 job_id>}]`.

제품 사진은 온보딩 때 OS의 승인된 media ingestion으로 받은 artifact ID를 쓴다. 원본·동의·사용권·hash가 OS 정본에 없으면 사용하지 않는다. 채팅 첨부를 provider로 우회 전달하지 않는다.

실제 사람의 얼굴·음성·신체가 들어가면 일반 광고 게재 동의만으로 provider에 보내지 않는다. provider별 AI 처리·파생 생성·국외 이전·보존/삭제·철회·만료 범위를 포함한 동의 receipt가 CandidateProvenance에 있어야 한다. 하나라도 누락·만료·철회되면 dispatch를 차단한다.

이전 라운드 소재를 변형할 때는 OS가 보존한 artifact와 provider request ID를 참조한다. 기존 bytes·권리·동의 currentness를 다시 검증하며 job ID만으로 동일성과 사용권을 가정하지 않는다.

### 실물이 없을 때 — 서비스·플랫폼·B2B

「실물 제품 사진을 레퍼런스로」는 물건을 파는 업체 기준이다. 상담·입점·교육처럼 **팔 물건이 없으면 그대로 적용할 수 없다.** 대신 무엇이 «실물»인지 다시 정의한다.

| 업종 | 실물에 해당하는 것 |
|---|---|
| 앱·플랫폼 | **앱 화면 캡처** — 실제 화면이어야 한다. 지어낸 UI를 넣으면 다운로드 후 실망으로 이어진다 |
| 출장·시공 서비스 | 실제 작업 현장 사진, 사용하는 장비 |
| 파트너·입점 모집 | 실제 활동 중인 파트너 사진, 실제 작업물 |
| 교육 | 실습 현장, 강의실, 실제 장비 |
| 아무것도 없는 신규 사업 | **사장님께 직접 찍어달라고 부탁한다** — 사무실, 장비, 본인 사진이라도 |

**있는 것으로 시작한다.** 완벽한 사진을 기다리다 광고를 못 시작하는 게 더 나쁘다. 스마트폰으로 찍은 현장 사진이 AI로 지어낸 스톡 이미지보다 반응이 좋은 경우가 많다.

**정말 아무 실물도 없으면** 텍스트 중심 포맷(아래 카탈로그의 Bold Statement, Benefits Checklist, Comparison Table, Whiteboard Explainer)으로 간다. 이 계열은 사진 없이도 성립한다. 다만 **사람이나 현장을 지어내지 않는다** — 없는 파트너, 없는 고객을 만들면 기만적 표시가 된다 (`references/policy-check.md`).

온보딩에서 사진을 받을 때 이 기준으로 요청한다:

> 제품 사진이 없으셔도 됩니다. **앱 화면이나 실제 작업하시는 모습, 장비 사진**이면 됩니다.
> 잘 찍은 사진이 아니어도 괜찮아요. 실제 모습인 게 더 중요합니다.

### 광고 포맷 카탈로그 — 이미지 테스트의 실제 팔레트

OS generation capability의 버전형 `ad_format` 목록에서 지원되는 이미지 광고 포맷을 조회한다. 아래 수량과 이름은 예시이며 provider 목록을 정본으로 보지 않는다. 영상 훅과 달리 이건 **광고의 설득 구조 그 자체**라 업종을 덜 가린다.

| 성격 | 포맷 |
|---|---|
| 신뢰·증거 | Customer Quote, Star Review, Trusted Review, Social Proof, Customer Story, Press Screenshot, Media Mentions |
| 차별화·비교 | Why We're Different, Comparison Table, Then vs Now, Before and After |
| 정보 전달 | Key Features, Benefits, Benefits Checklist, Whiteboard Explainer, Callout Notes, App Screenshot |
| 주목 유도 | Bold Statement, Hero Statement, Mystery Hook, Scroll Break, Highlighted Hook |
| 판매 압박 | Special Offer, Bundle Deal, Stat Surround |
| 자연스러움 | Organic Post, Trending Post, Personal Note, Social Comment, UGC Side-by-Side |

**소구점 태그와 포맷을 짝지어 테스트한다.** 「조건 투명」이라는 소구점은 Comparison Table 로도, Whiteboard Explainer 로도 표현된다 — 이게 2라운드(레이아웃) 테스트의 재료다.

#### 카탈로그의 3분의 1은 «근거가 있어야 쓸 수 있는» 것이다

실제로 조회해 보면 42개 중 **13개가 「남이 좋다고 말하는」 형식**이다.

> Customer Quote · Star Review · Trusted Review · Social Proof · Customer Story ·
> Press Screenshot · Media Mentions · Reaction Quote · Highlighted Comment ·
> Social Comment · Trending Post · Organic Post · UGC Side-by-Side

**이 계열은 실제 후기·기사·댓글이 있을 때만 쓴다.** 지어내면 기만적 표시가 된다 (`references/policy-check.md`). 카탈로그에 있다는 게 써도 된다는 뜻이 아니다.

`Special Offer`, `Bundle Deal` 은 할인 표시 규제 대상이다 — 할인 전 가격이 실제로 판매된 적 있어야 한다.

#### 근거 없이 바로 쓸 수 있는 것 — 신규 사업의 출발점

후기도 실적도 없는 업체는 여기서 고른다.

> Headline · Bold Statement · Hero Statement · Key Features · Benefits ·
> Benefits Checklist · Comparison Table · Whiteboard Explainer · Callout Notes ·
> Color Block · App Screenshot · Why We're Different · Mystery Hook · Scroll Break

서비스·B2B에서 특히 쓸 만한 것: **Why We're Different, Comparison Table, Benefits Checklist, Whiteboard Explainer, App Screenshot.**

#### 이름이 아니라 `id` 로 지정한다

조회 결과에 **이름이 중복되는 항목이 있다** (`Stat Surround` 가 서로 다른 `id` 로 두 개). 또 `librarian`, `picker` 처럼 **미리보기 이미지가 없는 내부용 항목**이 섞여 있다 — 이건 쓰지 않는다.

포맷을 고를 때는 이름으로 찾되 **`id` 로 지정**하고, `media` 가 `null` 인 항목은 후보에서 뺀다.

**주의: 이 포맷들은 전부 «이미지 위 텍스트»가 핵심이다.** 아래 「아직 약한 것」에 적힌 한글 깨짐 문제가 정면으로 걸린다. **첫 생성에서 한글이 제대로 나오는지 반드시 확인하고**, 깨지면 이 계열을 포기하거나 텍스트 없이 뽑아 별도로 얹는다. 확인 전에 이 포맷으로 여러 장 뽑지 않는다.

## 영상

| 상황 | 모델 |
|---|---|
| 제품 광고 기본 | `marketing_studio_video` (12~15초, 릴스/틱톡 규격, 오디오 포함) |
| 인물·제품 동일성이 중요 | `seedance_2_0` (레퍼런스 기반, 4~15초, 최대 4K) |
| 그 외 | OS가 허용한 model capability에서 탐색 |

세로(9:16)가 기본이다. 피드용으로 1:1 이나 4:5 가 필요하면 따로 뽑는다.

#### 영상 프리셋은 커머스 편향이 심하다

`marketing_studio_video` 의 프리셋 26종을 실제로 조회해 보면 **대부분이 물건을 파는 커머스용**이다 — Unboxing, Virtual Try-On, Reboxing, Crush Test, Mystery Box, Giant Figure.

**상담·입점·교육 같은 서비스업은 쓸 수 있는 게 확 줄어든다.** 실질적으로 넷이다:

| 프리셋 | 쓸 곳 |
|---|---|
| `ugc_direct_to_camera` | 사람이 카메라 보고 설명 — 가장 범용 |
| `ugc_how_to` (Tutorial) | 절차·방법 설명 |
| `tv_spot` | 정보 전달형 광고 |
| `wild_card` | 위 셋이 안 맞을 때 |

**커머스용 프리셋을 서비스업에 억지로 쓰지 않는다.** 언박싱할 물건이 없는데 언박싱 형식을 쓰면 어색하고, 무엇보다 **없는 제품을 만들어내게 된다.**

프리셋 없이 `wild_card` 나 일반 모델로 가는 것도 정당한 선택이다.

### 훅과 세팅

`marketing_studio_video` 는 훅(무엇으로 시선을 끌지)과 세팅(어디서)을 부품으로 받는다. 목록은 OS generation capability가 보존한 provider `hook` / `setting` snapshot에서 읽는다.

**첫 3초가 성과를 가른다.** 훅을 바꾸는 것은 소구점을 바꾸는 것만큼 큰 변수이므로, 훅 테스트와 메시지 테스트를 같은 라운드에 섞지 않는다.

**다만 기본 제공 훅은 대부분 소비재 UGC용 스턴트다.** 실제 목록을 조회해 보면 「물건이 얼굴로 날아든다」, 「백플립 실패 후 태연히 리뷰」, 「눈보라가 몰아쳐도 제품은 멀쩡」 같은 것들이다. 화장품·패션·가젯에는 맞지만 **서비스업·B2B·전문직 대상에는 우스꽝스럽게 보인다.**

| 업종 | 쓸 만한 프리셋 |
|---|---|
| 소비재·커머스 | `ugc`, `ugc_unboxing`, `ugc_before_and_after`, `product_showcase`, `crush_test` |
| **서비스·B2B·전문직** | `ugc_direct_to_camera`, `ugc_selfie_testimonial`, `ugc_how_to`(튜토리얼), `tv_spot` |
| 맞는 게 없을 때 | **`wild_card`** — 직접 서술한 아이디어대로 만든다. 서비스업의 탈출구 |

**억지로 훅을 붙이지 않는다.** 어색한 스턴트는 신뢰가 중요한 업종에서 역효과다. 맞는 게 없으면 훅 없이 간다.

훅/세팅은 UGC, Tutorial, Unboxing, Product Review 계열 프리셋에서만 동작한다. 다른 프리셋에 넘기면 무시된다.

**만들기 전에 목록을 직접 조회한다.** 프리셋은 계속 추가되므로 이 표를 그대로 믿지 않는다.

### 사람 소재와 아바타 (UGC)

사람이 말하는 UGC는 우선순위를 **동의받은 실제 출연자 촬영 → 실제 출연자 원본을 제한적으로 편집 → 비인간 배경·오브젝트 생성 → 문서화된 예외의 가상인물** 순으로 둔다. 실제 사람 레퍼런스를 보존할 수 없는 텍스트→이미지/영상 생성으로 고객·배우·전문가를 만들지 않는다.

가상인물 예외를 쓰면 출처·모델·버전·프롬프트 해시·최종 바이트 해시를 남기고, 독립 검토자 2명과 한국어 원어민이 얼굴·눈·치아·귀·머리카락·목·손·피부 나이 일관성·조명·반사·시간축 흔들림·음성·립싱크를 구조화해 검토한다. 미해결 치명/중대 결함이 하나라도 있으면 폐기한다. 2026년 한국 표시 요건이 적용되는 추천·보증형 가상인물에는 노출 전 구간 동안 안전영역 안에 `가상인물` 표시를 합성한다.

**그리고 아바타에게 «후기»를 말하게 하지 않는다.** 실제 고객이 아닌 사람이 사용 경험을 말하면 기만적 표시가 된다 (`references/policy-check.md`). 아바타는 **설명·안내 역할**로 쓴다 — "이런 경우엔 이렇게 확인하세요" 는 되고, "저도 써봤는데 좋더라고요" 는 안 된다.

같은 이유로 Customer Quote·Star Review·Social Proof 같은 후기형 광고 포맷은 **실제 자료가 있을 때만** 쓴다.

### 레퍼런스 광고 따라 만들기

경쟁사 광고는 공개 열람 가능한 시장 근거일 뿐 외부 생성 provider에 업로드할 권리를 주지 않는다. 공개 URL·snapshot hash에서 비표현적 구조(장면 수, 페이싱, 훅 유형)만 연구 근거로 기록한다.

구체적인 라이선스와 provider 처리 약관상 권한을 OS가 증명한 자사/허가 영상만 `ad_reference`로 등록할 수 있다. 근거가 없으면 원본 bytes·URL을 provider에 전달하지 않는다.

대행사가 하는 「레퍼런스 분석 후 벤치마킹」과 같은 작업이다. **베끼는 게 아니라 구조를 배우는 것** — 카피와 소구점은 우리 것을 쓴다.

허가된 `ad_reference`는 `hook_id`/`setting_id`와 함께 못 쓴다. 둘 중 하나만 고른다. 아바타·제품·라이선스·동의·provider 처리 근거는 OS generation spec에 명시적으로 결합한다.

## 캐러셀

카드 2~10장. 각 카드의 최종 bytes hash·순서·문구·placement QA를 하나의 승인된 carousel artifact manifest로 묶고 OS safe-write에 넘긴다.

캐러셀은 **순서에 이야기가 있어야** 의미가 있다. 같은 제품 사진 5장은 캐러셀을 쓸 이유가 없다. 쓸 만한 구성:

- 문제 → 원인 → 해결 → 결과 → 행동
- 사용 전 / 사용 후
- 기능 1~5 (각 카드에 다른 혜택)

## 아직 약한 것 — 알고 시작한다

- **화면 안 한글 텍스트** — 생성 모델에는 글자를 맡기지 않는다. 텍스트 없는 플레이트를 만들고 승인된 NFC 한글과 라이선스 폰트를 결정론적으로 합성한다. 최종 인코딩본의 권위 문구는 NFC 기준 CER=0과 원어민 의미 검토가 필수다
- **한국어 음성·립싱크** — 동의받은 실제 음성을 우선한다. 불가피한 합성음은 스크립트 일치, 한국어 ASR CER/sWER, 얼굴·입 검출 커버리지, SyncNet 계열 지표와 원어민 자연스러움 검토를 별도 기록한다. 지표 하나로 승인하지 않는다
- **전문 작업 장면** — 시공·수리 같은 실제 작업은 AI가 그럴듯하게 못 만들 수 있다. 도구를 잘못 쥐거나 손이 이상하면 그 업계 사람이 바로 알아본다. **해당 업종 종사자를 타겟으로 할 때 특히 위험하다.** 이런 장면은 사장님이 실제 현장 사진·영상을 주는 편이 낫다

## 포맷 테스트 순서

포맷은 소구점보다 큰 변수다. 계층을 나눈다.

```
0라운드   포맷      이미지 vs 영상 vs 캐러셀 (메시지 고정)
1라운드   소구점    검증된 기준 포맷 안에서 메시지만
2라운드   표현      검증된 기준 메시지 고정, 광고 포맷을 바꿔가며
                  (Customer Quote vs Comparison Table vs Whiteboard 등)
3라운드+  기준 방어  검증된 기준 소재 vs 새 도전자
```

2라운드에서 「시각 요소 하나」를 임의로 바꾸는 것보다, **검증된 광고 포맷 카탈로그에서 골라 바꾸는 편**이 재현 가능하고 대장에 기록하기도 좋다.

OS PostgreSQL 소재대장에 `포맷`과 genome hash를 반드시 적는다. 없으면 나중에 중복·조건을 검증할 수 없다.

**예산이 부족하면 포맷을 2종으로 줄인다.** 변형이 많아 각각 표본을 못 채우면 어느 것도 판단할 수 없다.
